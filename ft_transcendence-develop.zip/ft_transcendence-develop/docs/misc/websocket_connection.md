# Improvements.

change console.log for app.log.
using fastify.

const app = Fastify({ logger: true });
